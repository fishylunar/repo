let isRunning = false

let getCurrentTab = async () => {
  let queryOptions = { active: true, lastFocusedWindow: true }
  // `tab` will either be a `tabs.Tab` instance or `undefined`.
  let [tab] = await browser.tabs.query(queryOptions)

  return tab
}

let isCSPDisabled = async () => {
  let rules = await browser.declarativeNetRequest.getSessionRules(),
    urls = rules.map(rule => rule.condition.urlFilter),
    {url} = await getCurrentTab()

  return urls.some(item => item === url)
}



let disableCSP = async (id) => {
  if (isRunning) return
  isRunning = true
  
  let addRules = [],
    removeRuleIds = [],
    {url} = await getCurrentTab()

  if (!await isCSPDisabled()) {
    addRules.push({
      id,
      action: {
        type: 'modifyHeaders',
        responseHeaders: [{ header: 'content-security-policy', operation: 'set', value: '' }]
      },
      condition: {urlFilter: url, resourceTypes: ['main_frame', 'sub_frame']}
    })

    // browser.browsingData.remove({}, { serviceWorkers: true }, () => {})
  } else {
    let rules = await browser.declarativeNetRequest.getSessionRules()

    rules.forEach(rule => {
      if (rule.condition.urlFilter === url) {
        removeRuleIds.push(rule.id)
      }
    })
  }

  await browser.declarativeNetRequest.updateSessionRules({addRules, removeRuleIds})
  
  isRunning = false
}

function handleMessageEvent(message) {
    if(message.content === "disableCSP") {
        browser.tabs.query({active: true, currentWindow: true}, function(tabs) {
            if (tabs.length == 0) {
                console.log("could not send message to the current tab");
            } else {
                disableCSP(tabs[0].id)
                console.log("Disabling for: ", tabs[0].url)
            }
        });
    }
}

browser.runtime.onMessage.addListener((message) => handleMessageEvent(message))
