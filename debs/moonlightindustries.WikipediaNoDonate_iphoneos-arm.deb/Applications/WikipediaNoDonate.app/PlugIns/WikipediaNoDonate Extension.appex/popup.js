let debug = false;

document.getElementById("submitDelay").addEventListener("click", function(){
    browser.tabs.query({active: true, currentWindow: true}, function(tabs) {
        if (tabs.length == 0) {
            console.error("could not send message to the current tab");
        } else {
            let delayIn = document.getElementById("delayInput").value
            browser.tabs.sendMessage(tabs[0].id, {delay: Number(delayIn)} );
        }
    });
})

function handleMessageEvent(message) {
    var textarea = document.getElementById("debugLog");

    if(debug) {
        textarea.value += JSON.stringify(message, null, 2)
        
        if(textarea.selectionStart == textarea.selectionEnd) {
           textarea.scrollTop = textarea.scrollHeight;
        }
        
    } else {
        textarea.style.display = "none";
        document.getElementById("debugView").style.display = "none";
    }

    if(message.delayValue) {
        document.getElementById("delayInput").value = message.delayValue.toString()
    }
    if(Object.keys(message).includes("content")) {
        if(message.content === "currentPageInfo") {
            if(document.getElementById("collectBasic").checked) {
                document.getElementById("adsBlockedTooltip").innerText = `Found: ${message.foundAds}\nBlocked: ${message.blockedAds} / ${message.foundAds}\nFailed: ${message.failed}\nNot found: ${message.notFound}`
            } else {
                document.getElementById("adsBlockedTooltip").innerText = "Analytics turned off."
            }
        }
        if(message.content === "stats") {
            if(document.getElementById("collectBasic").checked) {
                let stats = message.statistics;
                document.getElementById("statisticsUI").innerText = JSON.stringify(stats, null, 2)
            }
        }
        if(message.content === "collectAnalytics") {
                    document.getElementById("collectBasic").checked = message.collectBasic
                    document.getElementById("collectAdvanced").checked = message.collectAdvanced
            let activeTab = false;
            browser.tabs.query({active: true, currentWindow: true}, function(tabs) {
                if (tabs.length == 0) {
                    console.log("could not send message to the current tab");
                } else {
                    activeTab = tabs[0];
                }
            });
            setTimeout(function() { // Here we add out DOM event listeners
                document.getElementById("collectBasic").addEventListener("change", function() {
                            browser.tabs.sendMessage(activeTab.id, {
                            content: "collectAnalyticsResponse",
                            collectBasic: document.getElementById("collectBasic").checked,
                            collectAdvanced: document.getElementById("collectAdvanced").checked
                            })
                })
                document.getElementById("collectAdvanced").addEventListener("change", function() {
                            browser.tabs.sendMessage(activeTab.id, {
                            content: "collectAnalyticsResponse",
                            collectBasic: document.getElementById("collectBasic").checked,
                            collectAdvanced: document.getElementById("collectAdvanced").checked
                            })
                })
                document.getElementById("clearData").addEventListener("click", function() {
                    browser.tabs.sendMessage(activeTab.id, {content: "clearData"})
                })
            }, 100)
            
            // Contine onload from here
            
            window.setTimeout(function() {
                if(message.collectBasic) {
                    browser.tabs.sendMessage(activeTab.id, {get: "pageInfo"})
                } else {
                    document.getElementById("adsBlockedTooltip").innerText = "Analytics turned off."
                    document.getElementById("statsView").style.display = "none";
                    document.getElementById("statisticsUI").style.display = "none";
                }
                if(message.collectBasic) {
                    browser.tabs.sendMessage(activeTab.id, {get: "stats"})
                }
                
            }, 100)
            
        }
    }
}

browser.runtime.onMessage.addListener((message) => handleMessageEvent(message))


window.onload = function() {
    //popup was opened
    
    // Show clear data button if debug is true
    if(debug) document.getElementById("clearData").style.display = "block"
    browser.tabs.query({active: true, currentWindow: true}, function(tabs) {
        if (tabs.length == 0) {
            console.log("could not send message to the current tab");
        } else {
            browser.tabs.sendMessage(tabs[0].id, {get: "delay"})
            browser.tabs.sendMessage(tabs[0].id, {get: "analyticsSettings"})
            // rest of onload is handled when we get a response to get: "analyticsSettings"
        }
    });
};





