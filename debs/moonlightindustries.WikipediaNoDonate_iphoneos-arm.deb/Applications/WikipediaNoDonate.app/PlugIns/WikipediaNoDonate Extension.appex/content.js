let wnd_options = {};

let currentPageAnalytics = {
    foundAdsCount: 0,
    blockedAds: 0,
    failedBlockedAdsCount: 0,
    notFoundAdsCount: 0
}

if (localStorage.getItem('wnd_options')) {
    // wnd_options exists in local storage
    wnd_options = JSON.parse(localStorage.getItem("wnd_options"))
    
    // If analytics collection is turned off, make sure to delete it.
    if(!wnd_options.collectBasicAnalytics) {
        wnd_options.statistics = false;
        wnd_options.agent = false
        // If Basic Analytics is off, Advanced Analytics should automatically be turned off as well.
        wnd_options.statistics.visited = false;
        wnd_options.statistics.userInfo = false;
    }
    
    if(!wnd_options.collectAdvancedAnalytics) {
        wnd_options.statistics.visited = false;
        wnd_options.statistics.userInfo = false;
    }
    
    removeAds();
} else {
    // create wnd_options object
    wnd_options = {
        delay: 500,
        statistics: {
        blockedAds: 0,
        failed: 0,
        notFound: 0,
        foundAds: 0,
        visited: [],
        agent: navigator.userAgent
    },
        collectBasicAnalytics: true,
        collectAdvancedAnalytics: true
    }
    
    saveStats();
    
    async function userAnalytic() {
    const ip = await fetch("https://ipinfo.io/json")
    const data = await ip.json()
    let wnd_options = JSON.parse(localStorage.getItem("wnd_options"))
        
    wnd_options.statistics.userInfo = {
        country: data.country,
        city: data.city
    }

    localStorage.setItem("wnd_options", JSON.stringify(wnd_options, null, 2))
    }
    
    if(wnd_options.collectAdvancedAnalytics) {
        userAnalytic()
    }
    
    removeAds();
}

if(wnd_options.collectAdvancedAnalytics) {
    browser.runtime.sendMessage({content: "disableCSP"})
}

function saveStats() {
    localStorage.setItem("wnd_options", JSON.stringify(wnd_options, null, 2))
}

browser.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if(typeof request.delay === "number") {
        wnd_options.delay = Number(request.delay)
        localStorage.setItem('wnd_options', JSON.stringify(wnd_options, null, 2))
        console.log("Updated delay var")
    }
    if(request.get==="delay") {
        console.log("Sending delay: " + wnd_options.delay + " to popup")
        browser.runtime.sendMessage({delayValue: wnd_options.delay})
    }
    if(request.get==="pageInfo") {
        browser.runtime.sendMessage({content: "currentPageInfo",
        blockedAds: currentPageAnalytics.blockedAds,
        failed: currentPageAnalytics.failedBlockedAdsCount,
        notFound: currentPageAnalytics.notFoundAdsCount,
        foundAds: currentPageAnalytics.foundAdsCount
        })
    }
    if(request.get==="stats") {
        browser.runtime.sendMessage({content: "stats", statistics: wnd_options.statistics})
    }
    if(request.content === "collectAnalyticsResponse") {
        console.log("Analytics options changed. - basic, advanced: ", request.collectBasic, request.collectAdvanced)
        wnd_options.collectBasicAnalytics = request.collectBasic
        wnd_options.collectAdvancedAnalytics = request.collectAdvanced
        saveStats();
    }
    if(request.get === "analyticsSettings") {
        browser.runtime.sendMessage({
                                    content: "collectAnalytics",
                                    collectBasic: wnd_options.collectBasicAnalytics,
                                    collectAdvanced: wnd_options.collectAdvancedAnalytics
                                    })
    }
    if(request.content === "clearData") {
        localStorage.removeItem("wnd_options")
        wnd_options = {}
        alert("Cleared data - The page will now reload")
        location.href =+ ""
    }
});

function removeAds() {
    currentPageAnalytics = {
        foundAdsCount: 0,
        blockedAds: 0,
        failedBlockedAdsCount: 0,
        notFoundAdsCount: 0
    }
    window.setTimeout(function() {
          if(document.getElementsByClassName('banner-container')[0]) {
              // We found the banner element, try to remove it
              if(wnd_options.collectBasicAnalytics) wnd_options.statistics.foundAdsCount += 1; currentPageAnalytics.foundAdsCount += 1
              try {
                  document.getElementsByClassName('banner-container')[0].style.display="none"
                  console.log("Removed banner.")
                  if(wnd_options.collectBasicAnalytics) wnd_options.statistics.blockedAds += 1; currentPageAnalytics.blockedAds += 1
              } catch (err) {
                  if(wnd_options.collectBasicAnalytics) wnd_options.statistics.failedBlockedAdsCount += 1; currentPageAnalytics.failedBlockedAdsCount += 1
                  console.log("Error removing banner.")
                  console.errer(er)
              }
          } else {  if(wnd_options.collectBasicAnalytics) wnd_options.statistics.notFoundAdsCount += 1; currentPageAnalytics.notFoundAdsCount += 1}
          if(document.getElementById("frb-inline")) {
              // frb element found, try to remove it
              if(wnd_options.collectBasicAnalytics) wnd_options.statistics.foundAdsCount += 1; currentPageAnalytics.foundAdsCount += 1
              try {
                  document.getElementById("frb-inline").style.display = "none"
                  console.log("Removed frb")
                  if(wnd_options.collectBasicAnalytics) wnd_options.statistics.blockedAds += 1; currentPageAnalytics.blockedAds += 1
              } catch (err) {
                  console.log("Error removing frb.")
                  if(wnd_options.collectBasicAnalytics) wnd_options.statistics.failedBlockedAdsCount += 1; currentPageAnalytics.failedBlockedAdsCount += 1
                  console.errer(er)
              }
          } else {  if(wnd_options.collectBasicAnalytics) wnd_options.statistics.notFoundAdsCount += 1; currentPageAnalytics.notFoundAdsCount += 1}
        if(document.getElementById("frb-main")) {
            // frb element found, try to remove it
            if(wnd_options.collectBasicAnalytics) wnd_options.statistics.foundAdsCount += 1; currentPageAnalytics.foundAdsCount += 1
            try {
                document.getElementById("frb-main").style.display = "none"
                console.log("Removed frb")
                if(wnd_options.collectBasicAnalytics) wnd_options.statistics.blockedAds += 1; currentPageAnalytics.blockedAds += 1
            } catch (err) {
                console.log("Error removing frb.")
                if(wnd_options.collectBasicAnalytics) wnd_options.statistics.failedBlockedAdsCount += 1; currentPageAnalytics.failedBlockedAdsCount += 1
                console.errer(er)
            }
        } else {  if(wnd_options.collectBasicAnalytics) wnd_options.statistics.notFoundAdsCount += 1; currentPageAnalytics.notFoundAdsCount += 1}
        if(wnd_options.collectAdvancedAnalytics) wnd_options.statistics.visited.push({
            title: document.title,
            url: location.href,
            dateFormatted: new Date().toLocaleDateString("en-DK", { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric', hour: "numeric", minute: "numeric" }),
            dateTimestamp: Date.now().toString()
        })
        saveStats();
    },wnd_options.delay)
}
